import { PrismaClient } from '@prisma/client';
import fs from 'fs/promises';
import path from 'path';

const prisma = new PrismaClient();
const booksFilePath = path.join(process.cwd(), 'src/data/books.json');

interface BookData {
  id: string;
  title: string;
  author: string;
  genre: string;
  year: number;
  pages: number;
  rating: number;
  synopsis?: string;
  cover?: string;
}

async function main() {
  console.log(`Iniciando a migração de dados...`);

  await prisma.book.deleteMany({});
  await prisma.genre.deleteMany({});
  console.log('Tabelas limpas.');

  const fileContents = await fs.readFile(booksFilePath, 'utf8');
  const booksData: BookData[] = JSON.parse(fileContents);

  for (const book of booksData) {
    const genre = await prisma.genre.upsert({
        where: { name: book.genre },
        update: {},
        create: { name: book.genre },
    });

    await prisma.book.create({
      data: {
        id: book.id,
        title: book.title,
        author: book.author,
        year: book.year,
        pages: book.pages,
        rating: book.rating,
        synopsis: book.synopsis,
        cover: book.cover,
        genreId: genre.id,
      },
    });
    console.log(`Livro criado: ${book.title}`);
  }

  console.log(`Migração de dados concluída com sucesso.`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });