export enum ReadingStatus {
  TO_READ = 'TO_READ',
  READING = 'READING',
  READ = 'READ',
}

export interface Book {
  id: string;
  title: string;
  author: string;
  genre: string;
  year: number;
  pages: number;
  rating: number;
  synopsis?: string;
  cover?: string;
}