"use server";

import prisma from "@/lib/prisma";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { BookFormValues, bookFormSchema } from "@/lib/schemas";

export async function createBook(data: BookFormValues) {
  try {
    const validatedData = bookFormSchema.parse(data);

    await prisma.book.create({
      data: {
        title: validatedData.title,
        author: validatedData.author,
        year: validatedData.year,
        pages: validatedData.pages,
        rating: validatedData.rating,
        status: validatedData.status,
        currentPage: validatedData.currentPage,
        synopsis: validatedData.synopsis,
        cover: validatedData.cover,
        isbn: validatedData.isbn,
        genre: validatedData.genre
          ? { connect: { id: validatedData.genre } }
          : undefined,
      },
    });
  } catch (error) {
    throw new Error("Falha ao criar o livro. Verifique os campos.");
  }

  revalidatePath("/books");
  redirect("/books");
}

export async function updateBook(id: string, data: BookFormValues) {
  try {
    const validatedData = bookFormSchema.parse(data);

    await prisma.book.update({
      where: { id },
      data: {
        title: validatedData.title,
        author: validatedData.author,
        year: validatedData.year,
        pages: validatedData.pages,
        rating: validatedData.rating,
        status: validatedData.status,
        currentPage: validatedData.currentPage,
        synopsis: validatedData.synopsis,
        cover: validatedData.cover,
        isbn: validatedData.isbn,
        genre: validatedData.genre
          ? { connect: { id: validatedData.genre } }
          : undefined,
      },
    });
  } catch (error) {
    throw new Error("Falha ao atualizar o livro. Verifique os campos.");
  }

  revalidatePath("/books");
  revalidatePath(`/books/${id}/edit`);
  redirect("/books");
}

export async function deleteBook(id: string) {
  await prisma.book.delete({
    where: { id },
  });

  revalidatePath("/books");
  redirect("/books");
}
