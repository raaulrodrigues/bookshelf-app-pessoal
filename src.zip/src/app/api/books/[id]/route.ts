import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { bookFormSchema } from "@/lib/schemas";

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
    const book = await prisma.book.findUnique({ where: { id: params.id }, include: { genre: true } });

    if (!book) {
        return NextResponse.json({ error: "Livro não encontrado." }, { status: 404 });
    }

    return NextResponse.json(book);
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
    const data = await request.json();
    const validatedFields = bookFormSchema.safeParse(data);

    if (!validatedFields.success) {
        return NextResponse.json({ error: "Dados inválidos." }, { status: 400 });
    }

    try {
        const updatedBook = await prisma.book.update({
            where: { id: params.id },
            data: validatedFields.data,
        });
        return NextResponse.json(updatedBook);
    } catch (error) {
        return NextResponse.json({ error: "Livro não encontrado." }, { status: 404 });
    }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
    try {
        await prisma.book.delete({ where: { id: params.id } });
        return new Response(null, { status: 204 });
    } catch (error) {
        return NextResponse.json({ error: "Livro não encontrado." }, { status: 404 });
    }
}