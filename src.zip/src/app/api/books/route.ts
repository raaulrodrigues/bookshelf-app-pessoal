import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { bookFormSchema } from "@/lib/schemas";

export async function GET() {
    const books = await prisma.book.findMany({ include: { genre: true } });
    return NextResponse.json(books);
}

export async function POST(request: NextRequest) {
    const data = await request.json();
    const validatedFields = bookFormSchema.safeParse(data);

    if (!validatedFields.success) {
        return NextResponse.json({ error: "Dados inválidos." }, { status: 400 });
    }

    const newBook = await prisma.book.create({
        data: validatedFields.data,
    });

    return NextResponse.json(newBook, { status: 201 });
}