import prisma from '@/lib/prisma';
import BookCard from '@/components/BookCard';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { BookPlus } from 'lucide-react';

export default async function BooksPage() {
  const books = await prisma.book.findMany({
    orderBy: { createdAt: 'desc' },
    include: { genre: true },
  });

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Minha Biblioteca</h2>
        <Link href="/books/add">
          <Button>
            <BookPlus className="mr-2 h-4 w-4" /> Adicionar Livro
          </Button>
        </Link>
      </div>
      {books.length > 0 ? (
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
          {books.map((book) => (
            <BookCard key={book.id} book={book} />
          ))}
        </div>
      ) : (
        <div className="text-center text-muted-foreground mt-10">
          <p>Nenhum livro encontrado.</p>
        </div>
      )}
    </div>
  );
}