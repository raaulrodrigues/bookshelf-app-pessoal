import BookForm from "@/components/BookForm";
import { createBook } from "@/app/actions";
import prisma from "@/lib/prisma";

export default async function AddBookPage() {
  const genres = await prisma.genre.findMany();

  return (
    <div className="max-w-2xl mx-auto">
      <h2 className="text-3xl font-bold tracking-tight mb-8">Adicionar Novo Livro</h2>
      <BookForm onSave={createBook} genres={genres} />
    </div>
  );
}