import { updateBook } from "@/app/actions";
import BookForm from "@/components/BookForm";
import prisma from "@/lib/prisma";
import { notFound } from "next/navigation";
import DeleteBookButton from "@/components/DeleteBookButton";

interface EditBookPageProps {
    params: { id: string; }
}

export default async function EditBookPage({ params }: EditBookPageProps) {
    const book = await prisma.book.findUnique({
        where: { id: params.id },
        include: { genre: true },
    });

    const genres = await prisma.genre.findMany();

    if (!book) {
        return notFound();
    }

    const updateBookWithId = updateBook.bind(null, book.id);

    return (
        <div className="max-w-2xl mx-auto">
            <div className="flex items-center justify-between mb-8">
                <h2 className="text-3xl font-bold tracking-tight">Editar Livro</h2>
                <DeleteBookButton id={book.id} />
            </div>
            <BookForm onSave={updateBookWithId} defaultValues={book} genres={genres} />
        </div>
    );
}