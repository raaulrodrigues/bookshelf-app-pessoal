import fs from 'fs/promises';
import path from 'path';
import { Book } from '@/types';

const booksFilePath = path.join(process.cwd(), 'src/data/books.json');

export async function getBooks(): Promise<Book[]> {
  try {
    const fileContents = await fs.readFile(booksFilePath, 'utf8');
    const books = JSON.parse(fileContents);
    return books;
  } catch (error) {
    console.error("Failed to read books data:", error);
    return [];
  }
}