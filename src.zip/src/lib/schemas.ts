import { z } from "zod";

export const bookFormSchema = z.object({
  title: z.string().min(2, { message: "O título é obrigatório." }),
  author: z.string().min(2, { message: "O autor é obrigatório." }),
  cover: z.string().url().optional().nullable(),
  year: z.coerce.number().int().positive(),
  pages: z.coerce.number().int().positive(),
  rating: z.coerce.number().min(1).max(5),
  synopsis: z.string().optional().nullable(),
  status: z.string().min(1, { message: "Selecione um status." }),
  currentPage: z.coerce.number().int().min(0),
  notes: z.string().optional().nullable(),
  isbn: z.string().optional().nullable(),
  genreId: z.string().min(1, { message: "Selecione um gênero." }),
});

export type BookFormValues = z.infer<typeof bookFormSchema>;