import React from "react"

export default function RatingStars({ value = 0, onChange }: { value?: number; onChange: (n:number)=>void }) {
  const stars = [1,2,3,4,5]
  return (
    <div>
      {stars.map((s) => (
        <button
          key={s}
          type="button"
          aria-label={`${s} estrelas`}
          onClick={() => onChange(s)}
          style={{ background: "transparent", border: "none", cursor: "pointer", fontSize: 20 }}
        >
          {s <= (value ?? 0) ? "★" : "☆"}
        </button>
      ))}
    </div>
  )
}
