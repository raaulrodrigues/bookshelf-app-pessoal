import { Book, Genre } from '@prisma/client';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from './ui/card';
import Image from 'next/image';
import Link from 'next/link';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

interface BookWithGenre extends Book {
    genre?: Genre | null;
}

interface BookCardProps {
    book: BookWithGenre;
}

export default function BookCard({ book }: BookCardProps) {
    const ratingValue = Number(book.rating);

    const statusVariant = {
        LENDO: 'default',
        LIDO: 'secondary',
        QUERO_LER: 'outline',
        PAUSADO: 'destructive',
        ABANDONADO: 'destructive',
    } as const;

    return (
        <Card className="flex flex-col">
            <CardHeader>
                <div className="relative w-full h-48 mb-4">
                    <Image
                        src={book.cover ?? '/fallback-cover.png'}
                        alt={`Capa do livro ${book.title}`}
                        fill
                        style={{ objectFit: 'contain' }}
                        sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                    />
                </div>
                <CardTitle className="text-lg leading-tight">{book.title}</CardTitle>
                <p className="text-sm text-muted-foreground">{book.author}</p>
            </CardHeader>
            <CardContent className="flex-grow space-y-2">
                <div>
                    <Badge variant="secondary">{book.genre?.name ?? 'Sem gênero'}</Badge>
                </div>
                <div>
                    <Badge variant={statusVariant[book.status as keyof typeof statusVariant]}>
                        {book.status.replace('_', ' ')}
                    </Badge>
                </div>
                <div className="text-sm flex items-center">
                    {[1, 2, 3, 4, 5].map((starValue) => (
                        <span
                            key={starValue}
                            className={starValue > ratingValue ? 'text-muted-foreground' : ''}
                        >
                            ⭐
                        </span>
                    ))}
                </div>
            </CardContent>
            <CardFooter>
                <Button asChild className="w-full">
                    <Link href={`/books/${book.id}/edit`}>Ver / Editar</Link>
                </Button>
            </CardFooter>
        </Card>
    );
}
