"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { Book, Genre } from "@prisma/client";
import { bookFormSchema, BookFormValues } from "@/lib/schemas";

const readingStatusOptions = ["QUERO_LER", "LENDO", "LIDO", "PAUSADO", "ABANDONADO"] as const;

interface BookFormProps {
  onSave: (data: BookFormValues) => Promise<any>;
  genres: Genre[];
  defaultValues?: Partial<Book & { genre: Genre }>;
}

export default function BookForm({ onSave, genres, defaultValues }: BookFormProps) {
  const form = useForm<BookFormValues>({
    resolver: zodResolver(bookFormSchema),
    defaultValues: { ...defaultValues, genreId: defaultValues?.genreId ?? "" },
  });

  async function onSubmit(data: BookFormValues) {
    const promise = onSave(data);
    toast.promise(promise, {
      loading: 'Salvando livro...',
      success: `Livro ${defaultValues ? 'atualizado' : 'criado'} com sucesso!`,
      error: 'Ocorreu um erro ao salvar o livro.',
    });
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <FormField control={form.control} name="title" render={({ field }) => ( <FormItem> <FormLabel>Título</FormLabel> <FormControl><Input placeholder="Título do livro" {...field} /></FormControl> <FormMessage /> </FormItem> )}/>
        <FormField control={form.control} name="author" render={({ field }) => ( <FormItem> <FormLabel>Autor</FormLabel> <FormControl><Input placeholder="Autor do livro" {...field} /></FormControl> <FormMessage /> </FormItem> )}/>
        <FormField control={form.control} name="cover" render={({ field }) => ( <FormItem> <FormLabel>URL da Capa</FormLabel> <FormControl><Input placeholder="https://..." {...field} value={field.value ?? ''} /></FormControl> <FormMessage /> </FormItem> )}/>
        <FormField control={form.control} name="genreId" render={({ field }) => ( <FormItem> <FormLabel>Gênero</FormLabel> <Select onValueChange={field.onChange} defaultValue={field.value}> <FormControl><SelectTrigger><SelectValue placeholder="Selecione um gênero" /></SelectTrigger></FormControl> <SelectContent>{genres.map(g => <SelectItem key={g.id} value={g.id}>{g.name}</SelectItem>)}</SelectContent> </Select> <FormMessage /> </FormItem> )}/>
        <FormField control={form.control} name="year" render={({ field }) => ( <FormItem> <FormLabel>Ano</FormLabel> <FormControl><Input type="number" placeholder="2024" {...field} onChange={e => field.onChange(e.target.value === '' ? undefined : +e.target.value)} /></FormControl> <FormMessage /> </FormItem> )}/>
        <FormField control={form.control} name="pages" render={({ field }) => ( <FormItem> <FormLabel>Páginas</FormLabel> <FormControl><Input type="number" placeholder="300" {...field} onChange={e => field.onChange(e.target.value === '' ? undefined : +e.target.value)}/></FormControl> <FormMessage /> </FormItem> )}/>
        <FormField control={form.control} name="currentPage" render={({ field }) => ( <FormItem> <FormLabel>Página Atual</FormLabel> <FormControl><Input type="number" placeholder="0" {...field} onChange={e => field.onChange(e.target.value === '' ? undefined : +e.target.value)}/></FormControl> <FormMessage /> </FormItem> )}/>
        <FormField control={form.control} name="rating" render={({ field }) => ( <FormItem> <FormLabel>Avaliação (1-5)</FormLabel> <FormControl><Input type="number" placeholder="5" {...field} onChange={e => field.onChange(e.target.value === '' ? undefined : +e.target.value)}/></FormControl> <FormMessage /> </FormItem> )}/>
        <FormField control={form.control} name="status" render={({ field }) => ( <FormItem> <FormLabel>Status</FormLabel> <Select onValueChange={field.onChange} defaultValue={field.value}> <FormControl><SelectTrigger><SelectValue placeholder="Selecione um status" /></SelectTrigger></FormControl> <SelectContent>{readingStatusOptions.map(s => <SelectItem key={s} value={s}>{s.replace('_', ' ')}</SelectItem>)}</SelectContent> </Select> <FormMessage /> </FormItem> )}/>
        <FormField control={form.control} name="isbn" render={({ field }) => ( <FormItem> <FormLabel>ISBN (Opcional)</FormLabel> <FormControl><Input placeholder="978-3-16-148410-0" {...field} value={field.value ?? ''} /></FormControl> <FormMessage /> </FormItem> )}/>
        <FormField control={form.control} name="synopsis" render={({ field }) => ( <FormItem> <FormLabel>Sinopse (Opcional)</FormLabel> <FormControl><Textarea placeholder="Descreva o livro..." {...field} value={field.value ?? ''} /></FormControl> <FormMessage /> </FormItem> )}/>
        <FormField control={form.control} name="notes" render={({ field }) => ( <FormItem> <FormLabel>Suas Anotações (Opcional)</FormLabel> <FormControl><Textarea placeholder="O que você achou do livro..." {...field} value={field.value ?? ''} /></FormControl> <FormMessage /> </FormItem> )}/>
        <Button type="submit" disabled={form.formState.isSubmitting}>
          {form.formState.isSubmitting ? 'Salvando...' : 'Salvar Livro'}
        </Button>
      </form>
    </Form>
  );
}